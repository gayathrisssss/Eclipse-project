package com.example.averagecalculation;



import android.os.Bundle;
import android.app.Activity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {

    private EditText num1, num2, num3, tot, avg;
    private Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); 
        
        num1=(EditText)findViewById(R.id.num1);
        num2=(EditText)findViewById(R.id.num2);
        num3=(EditText)findViewById(R.id.num3);
        
        tot=(EditText)findViewById(R.id.tot);
        avg=(EditText)findViewById(R.id.avg);
        
        button1=(Button)findViewById(R.id.button1);

        button1.setOnClickListener(new View.OnClickListener() 
        {
            @Override
            public void onClick(View v) 
            {
                try {
                    float m1=Float.parseFloat(num1.getText().toString());
                    float m2=Float.parseFloat(num2.getText().toString());
                    float m3=Float.parseFloat(num3.getText().toString());

                    float total= m1+m2+m3;
                    float average=total/3;

                    tot.setText(String.valueOf(total));
                    avg.setText(String.valueOf(average));

                } catch (NumberFormatException e) {
                    tot.setText("");
                    avg.setText("Enter Valid Number");
                }
            }
            
            
			
        });
    }
}
